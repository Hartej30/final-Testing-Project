//package week10;
//
//import org.junit.AfterClass;
//import org.junit.Assert;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.firefox.FirefoxDriver;
//
//public class AssertionsTest {
//
//    public static WebDriver driver;
//    public static String myWebDriverType = "webdriver.gecko.driver";
//    public static String myWebDriverPath = "C:\\Users\\harte\\drivers\\chromedriver.exe";
//
//    @BeforeClass
//    public static void setup() throws InterruptedException {
//        System.setProperty(myWebDriverType, myWebDriverPath);
//        driver = new FirefoxDriver();
//        driver.get("http://www.ebay.com/");
//        driver.manage().window().maximize();
//        Thread.sleep(3000);
//    }
//
//    @Test
//    public void logoTest(){
//        WebElement logo = driver.findElement(By.id("gh-logo"));
//        Assert.assertTrue(logo.isDisplayed());
//    }
//
//    @Test
//    public void assertTureTest() throws InterruptedException {
//        String searchItem = "JBL Speakers";
//        String expectedPrice = "$119.95";
//
//        driver.findElement(By.id("gh-ac")).clear();
//        driver.findElement(By.id("gh-ac")).sendKeys(searchItem);
//        driver.findElement(By.id("gh-btn")).click();
//        Thread.sleep(2000);
//
//        boolean b = driver.getPageSource().contains(expectedPrice);
//        Assert.assertTrue(b);
//    }
//
//    @Test
//    public void assertEqualsGetTitleTest(){
//        driver.navigate().to("http://ebay.com");
//        driver.navigate().refresh();
//        String actualTitle = driver.getTitle();
//        String expectedTitle = "Electronics, Cars, Fashion, Collectibles & More | eBay";
//
////        Assert.assertEquals(title, "abc", "web page title doesn't match.");
//        Assert.assertEquals(
//                "My expected page title is " + expectedTitle + " is not equals to the actual page title " + actualTitle,
//                expectedTitle,
//                actualTitle);
//    }
//
//    @Test
//    public void assertEqualsGetTextTest() throws InterruptedException {
//        String searchItem = "Wommen Shoes";
//        String expectedPrice = "$84.00";
//
//        driver.findElement(By.id("gh-ac")).clear();
//        driver.findElement(By.id("gh-ac")).sendKeys(searchItem);
//        driver.findElement(By.id("gh-btn")).click();
//        Thread.sleep(2000);
//
//        String webElement = "#item243a4bb6a0 > div > div.s-item__info.clearfix > div.s-item__details.clearfix > div:nth-child(1) > span";
//        String actualPrice = driver.findElement(By.cssSelector(webElement)).getText();
//        Assert.assertEquals(
//                "My expected price is " + expectedPrice + " but actual price is " + actualPrice,
//                expectedPrice,
//                actualPrice);
//    }
//
//    @AfterClass
//    public static void tearDown(){
//        driver.quit();
//    }
//}