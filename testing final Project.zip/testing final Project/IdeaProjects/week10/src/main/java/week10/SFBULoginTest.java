//package week10;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//
//public class SFBULoginTest {
//    public static void main(String[] args) throws InterruptedException {
//        System.setProperty("web driver.gecko.driver", "C:\\Users\\harte\\drivers\\geckodriver.exe");
//        WebDriver driver = new FirefoxDriver();
//
//        // Open SFBU Student login page
//        driver.get("https://sfbu.edu");
//        Thread.sleep(2000);
//
//        // click tab bar menu MYSFBU to open Applicant Portal
//        driver.findElement(By.cssSelector("#block-sfbu-mainnavigationright > ul > li.expanded.dropdown.has-dropdown > a")).click();
//        Thread.sleep(2000);
//
//        // input "myName@student.sfbu.edu" in Email
//        driver.findElement(By.id("UserName")).sendKeys("myName@student.sfbu.edu");
//
//        // click Forgot Password link and go back
//        driver.findElement(By.linkText("Forgot Password")).click();
//        Thread.sleep(2000);
//        driver.navigate().back();
//        Thread.sleep(2000);
//
//        // input "myPassword@123" in Password
//        driver.findElement(By.id("Password")).sendKeys("myPassword@123");
//
//        // click Button Log On
//        driver.findElement(By.cssSelector("input[type='submit']")).click();
//
//        // verify it should display the message
//        String expectedMsg = "Login was unsuccessful. Please correct the errors and try again.";
//        boolean b = driver.getPageSource().contains(expectedMsg);
//        if (b){
//            System.out.println("Test Passed!");
//        } else {
//            System.out.println("Test Failed");
//        }
//
//        // Close all open browsers and sessions
//        driver.quit();
//    }
//}
