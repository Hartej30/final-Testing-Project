package week10;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.File;
import java.time.Duration;

public class TestEbaySearchTakeScreenshots {
    public static WebDriver driver;
    static String myWebDriverType = "webdriver.gecko.driver";
    static String myWebDriverPath = "C:\\Users\\harte\\drivers\\geckodriver.exe";
    static String screenshotPath = "c://CS522Screenshots";
    static String url = "http://www.ebay.com/";
    static String msg = "not found the price meets my expectation ";
    static String item1 = "JBL Speakers";
    static String price1a = "$119.95";
    static String price1b = "$299.95";
    static String price1c = "$39.98";

    static String item2 = "cell phones";
    static String price2a = "360.54";
    static String price2b = "$228.99";
    static String price2c = "$69.99";

    static String item3 = "womens shoes";
    static String price3a = "$19.99";
    static String price3b = "$99.00";
    static String price3c = "$109.99";

    @BeforeClass
    public static void setup() {
        System.setProperty(myWebDriverType, myWebDriverPath);
        driver = new FirefoxDriver();
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }

    @AfterClass
    public static void tearDown() {
        driver.quit();
    }

    @Test
    public void searchJBLSpeakersComparePrices() throws Exception {
        searchItem(item1, price1a, price1b, price1c);
        takeSnapShot(driver, screenshotPath + "//" + "test1.png") ;
    }

    @Test
    public void searchWomensShowsComparePrices() throws Exception {
        searchItem(item3, price3a, price3b, price3c);
        takeSnapShot(driver, screenshotPath + "//" + "test3.png") ;
    }

    @Test
    public void searchCellPhoneComparePrices() throws Exception {
        searchItem(item2, price2a, price2b, price2c);
        takeSnapShot(driver, screenshotPath + "//" + "test2.png") ;
    }

    public void searchItem(String item, String priceA, String priceB, String priceC) {
        driver.findElement(By.id("gh-ac")).clear();
        driver.findElement(By.id("gh-ac")).sendKeys(item);
        driver.findElement(By.id("gh-btn")).click();
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));

        boolean b = driver.getPageSource().contains(priceA) ||
                driver.getPageSource().contains(priceB) ||
                driver.getPageSource().contains(priceC);
        Assert.assertTrue(b);
    }

    public void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception {
        //Convert web driver object to TakeScreenshot
        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

        //Call getScreenshotAs method to create image file
        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

        //Move image file to new destination
        File DestFile=new File(fileWithPath);

        //Copy file at destination
        FileUtils.copyFile(SrcFile, DestFile);
    }
}