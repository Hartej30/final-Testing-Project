//package week10;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import java.time.Duration;
//
//public class Testebayamazon {
//    WebDriver driver;
//    WebDriverWait wait;
//    String myWebBrowserDriver = "webdriver.gecko.driver";
//    String myWebBrowserDriverPath = "C:\\Users\\harte\\drivers\\geckodriver.exe";
//    String urlEbay = "http://www.ebay.com/";
//    String expectedAmazonPageTitleAfterSearch = "Amazon.com : JBL Speakers";
//    String urlAmazon = "http://www.amazon.com/";
//    String mySearchItem = "JBL Speakers";
//    String myCategory = "Electronics";
//    String lnkBestSellers = "Best Sellers";
//
//    void launchBrowserGoToAmazon() throws InterruptedException {
//        System.setProperty(myWebBrowserDriver, myWebBrowserDriverPath);
//        driver = new FirefoxDriver();
//        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        driver.get(urlAmazon);
//        Thread.sleep(000);
//    }
//
//
//
//    void openLinkBestSellers() throws InterruptedException {
//        WebElement bestSellersLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText(lnkBestSellers)));
//        bestSellersLink.click();
//        Thread.sleep(1000);
//    }
//
//    void selectCategory() {
//        Select categoryDropdown = new Select(driver.findElement(By.id("searchDropdownBox")));
//        categoryDropdown.selectByVisibleText(myCategory);
//    }
//
//    void navigateToEbayGoBack() throws InterruptedException {
//        driver.navigate().to(urlEbay);
//        Thread.sleep(1000);
//        System.out.println("Now navigate to Ebay page title is " + driver.getTitle());
//        driver.navigate().back();
//        Thread.sleep(1000);
//        System.out.println("Now navigate back to Amazon page title is " + driver.getTitle());
//        if (driver.getTitle().contentEquals(expectedAmazonPageTitleAfterSearch)) {
//            System.out.println("Test Passed!");
//        } else {
//            System.out.println("Test Failed");
//        }
//    }
//
//    void closeExit() {
//        driver.quit();
//    }
//
//    public static void main(String[] args) throws InterruptedException {
//        Testebayamazon obj = new Testebayamazon();
//        obj.launchBrowserGoToAmazon();
//        obj.maximizeWindowSize();
//        obj.selectCategory();
//        obj.searchProduct();
//        obj.openLinkBestSellers();
//        obj.navigateToEbayGoBack();
//        obj.closeExit();
//    }
//}
