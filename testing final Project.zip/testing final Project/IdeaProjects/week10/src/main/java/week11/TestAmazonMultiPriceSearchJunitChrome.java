//package week11;
//
//import org.apache.commons.io.FileUtils;
//import org.junit.AfterClass;
//import org.junit.Assert;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import org.openqa.selenium.By;
//import org.openqa.selenium.OutputType;
//import org.openqa.selenium.TakesScreenshot;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import java.io.File;
//import java.text.SimpleDateFormat;
//import java.time.Duration;
//import java.util.Date;
//
//public class TestAmazonMultiPriceSearchJunitChrome {
//    public static WebDriver driver;
//
//    public static String myWebBrowserDriver = "webdriver.chrome.driver";
//    public static String myDriverPath = "C:\\Users\\harte\\drivers\\chromedriver-win64 (5)\\chromedriver-win64\\chromedriver.exe";
//    public static String url = "http://www.amazon.com/";
//    static String screenshotPath = "C:\\ CS522 Screenshots";
//    public static String msg = "not found the price meets my expectation ";
//
//    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");
//    Date date = new Date();
//
//    @BeforeClass
//    public static void setup() throws InterruptedException {
//        System.setProperty(myWebBrowserDriver, myDriverPath);
//        driver = new ChromeDriver();
//        System.out.println("Opening browser!");
//        driver.get(url);
//        driver.manage().window().maximize();
//        Thread.sleep(20000);
//    }
//
//    @AfterClass
//    public static void tearDown(){
//        System.out.println("Close browser!");
//        driver.quit();
//    }
//
//    @Test
//    public void searchItem1() throws Exception {
//        String item1 = "Apple watch";
//        String price1a = "$359.18";
//        String price1b = "$560.90";
//        String price1c = "$239.99";
//        driver.findElement(By.name("field-keywords")).clear();
//        driver.findElement(By.name("field-keywords")).sendKeys(item1);
//        driver.findElement(By.id("nav-search-submit-button")).click();
//
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//        String fileName = "testitem1_" + dateFormat.format(date) + ".png";
//        takeSnapShot(driver, screenshotPath + "//" + fileName);
//
//        boolean b = driver.getPageSource().contains(price1a) ||
//                driver.getPageSource().contains(price1b) ||
//                driver.getPageSource().contains(price1c);
//
//        try {
//            Assert.assertTrue(b);
//            System.out.println("Price match found for item1");
//        } catch(Throwable t) {
//            System.out.println("Expected price not found!");
//        }
//    }
//
//    @Test
//    public void searchItem2() throws Exception {
//        String item2 = "Jacket";
//        String price2a = "$80.00";
//        String price2b = "$45.99";
//        String price2c = "$100.00";
//        driver.findElement(By.name("field-keywords")).clear();
//        driver.findElement(By.name("field-keywords")).sendKeys(item2);
//        driver.findElement(By.id("nav-search-submit-button")).click();
//
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//
//        String fileName = "testitem2_" + dateFormat.format(date) + ".png";
//        takeSnapShot(driver, screenshotPath + "//" + fileName);
//
//        boolean b = driver.getPageSource().contains(price2a) ||
//                driver.getPageSource().contains(price2b) ||
//                driver.getPageSource().contains(price2c);
//
//        try {
//            Assert.assertTrue(b);
//            System.out.println("Price match found for item2");
//        } catch(Throwable t) {
//            System.out.println("Expected price not found!");
//        }
//
//    }
//
//    @Test
//    public void searchItem3() throws Exception {
//        String item3 = "Bluetooth Pen";
//        String price3a = "$78.80";
//        String price3b = "120.99";
//        String price3c = "98.95";
//        driver.findElement(By.name("field-keywords")).clear();
//        driver.findElement(By.name("field-keywords")).sendKeys(item3);
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("nav-search-submit-button")));
//        driver.findElement(By.id("nav-search-submit-button")).click();
//
//        String fileName = "testitem3_" + dateFormat.format(date) + ".png";
//        takeSnapShot(driver, screenshotPath + "//" + fileName);
//
//        boolean b = driver.getPageSource().contains(price3a) ||
//                driver.getPageSource().contains(price3b) ||
//                driver.getPageSource().contains(price3c);
//
//        try {
//            Assert.assertTrue(b);
//            System.out.println("Price match found for item3");
//        } catch(Throwable t) {
//            System.out.println("Expected price not found!");
//        }
//    }
//
//    public void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception {
//        TakesScreenshot scrShot =((TakesScreenshot)webdriver);
//
//        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
//        File DestFile=new File(fileWithPath);
//
//        FileUtils.copyFile(SrcFile, DestFile);
//    }
//
//}