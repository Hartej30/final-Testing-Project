package week11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.time.Duration;

public class TestEbayMultiPricesSearchTestNG {
    WebDriver driver;
    String myWebBrowserDriver = "webdriver.chrome.driver";
    String myDriverPath = "C:\\Users\\harte\\drivers\\chromedriver-win64 (5)\\chromedriver-win64\\chromedriver.exe";
    int sleepTime = 5000;
    String msg = "not found the price meets my expectation ";

    String item1 = "JBL Speakers";
    String price1a = "$119.95";
    String price1b = "$179.95";
    String price1c = "$60.00";

    String item2 = "cell phones";
    String price2a = "$217.00";
    String price2b = "$109.47";
    String price2c = "$155.45";

    String item3 = "womens shoes";
    String price3a = "$32.49";
    String price3b = "$32.99";
    String price3c = "$55.00";

    @BeforeTest
    void setup() {
        System.setProperty(myWebBrowserDriver, myDriverPath);
        driver = new ChromeDriver();
        driver.get("http://www.amazon.com/");
        driver.manage().window().maximize();
    }

    @AfterTest
    void tearDown() {
        driver.quit();
    }

    @Test(priority = 3)
    void searchJBLSpeakersComparePrices() throws InterruptedException {
        searchItem(item1, price1a, price1b, price1c);
    }

    @Test(priority = 1)
    void searchWomensShowsComparePrices() throws InterruptedException {
        searchItem(item3, price3a, price3b, price3c);
    }

    @Test(priority = 2, enabled = false)
    void searchCellPhoneComparePrices() throws InterruptedException {
        searchItem(item2, price2a, price2b, price2c);
    }

    // Method to search for an item on Amazon
    void searchItem(String item) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Ensure the driver has navigated to Amazon and the page is loaded
        driver.get("http://www.amazon.com/");

        // Wait for the search box to be visible and clear it
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("twotabsearchtextbox"))).clear();

        // Send the search term to the search box
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys(item);

        // Click the search button
        driver.findElement(By.id("nav-search-submit-button")).click();
    }



    // Overloaded method to search for an item and verify prices
    void searchItem(String item, String priceA, String priceB, String priceC) throws InterruptedException {
        driver.findElement(By.id("gh-ac")).clear();
        driver.findElement(By.id("gh-ac")).sendKeys(item);
        driver.findElement(By.id("gh-btn")).click();
        Thread.sleep(sleepTime); // Consider replacing with WebDriverWait for better reliability
        boolean b = driver.getPageSource().contains(priceA) ||
                driver.getPageSource().contains(priceB) ||
                driver.getPageSource().contains(priceC);
        Assert.assertTrue(b, msg + priceA + " or " + priceB + " or " + priceC);
    }
}
