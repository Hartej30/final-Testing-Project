//package week10;
//
//import org.junit.AfterClass;
//import org.junit.Assert;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
////import org.testng.Assert;
////import org.testng.annotations.AfterTest;
////import org.testng.annotations.BeforeTest;
////import org.testng.annotations.Test;
//
//public class TestEbayMultiPricesSearchJunit {
//    public static WebDriver driver;
//
//    public static String myWebBrowserDriver = "webdriver.chrome.driver";
//    public static String myDriverPath = "C:\Users\harte\drivers\chromedriver.exe";
//    public static String url = "http://www.ebay.com/";
//    int sleepTime = 5000;
//    public static String msg = "not found the price meets my expectation ";
//
//    public static String item1 = "JBL Speakers";
//    public static String price1 = "$119.95";
//
//    String item2 = "cell phones";
//    String price2a = "$217.00";
//    String price2b = "$109.47";
//    String price2c = "$155.45";
//
//    String item3 = "womens shoes";
//    String price3a = "$32.49";
//    String price3b = "$32.99";
//    String price3c = "$55.00";
//
//    @BeforeClass
//    public static void setup(){
//        System.setProperty(myWebBrowserDriver, myDriverPath);
//        driver = new ChromeDriver();
//        driver.get(url);
//        driver.manage().window().maximize();
//    }
//
//    @AfterClass
//    public static void tearDown(){
//        driver.quit();
//    }
//
//    @Test
//    public void searchItem1() throws InterruptedException {
//        driver.findElement(By.id("gh-ac")).clear();
//        driver.findElement(By.id("gh-ac")).sendKeys(item1);
//        driver.findElement(By.id("gh-btn")).click();
//        Thread.sleep(sleepTime);
//        boolean b = driver.getPageSource().contains(price1);
//        Assert.assertTrue(b);
//    }
//
//    @Test
//    public void searchItem3() throws InterruptedException {
//        driver.findElement(By.id("gh-ac")).clear();
//        driver.findElement(By.id("gh-ac")).sendKeys(item3);
//        driver.findElement(By.id("gh-btn")).click();
//        Thread.sleep(sleepTime);
//        boolean b = driver.getPageSource().contains(price3a) ||
//                driver.getPageSource().contains(price3b) ||
//                driver.getPageSource().contains(price3c);
//        Assert.assertTrue(b);
//    }
//
//    @Test
//    public void searchItem2() throws InterruptedException {
//        driver.findElement(By.id("gh-ac")).clear();
//        driver.findElement(By.id("gh-ac")).sendKeys(item2);
//        driver.findElement(By.id("gh-btn")).click();
//        Thread.sleep(sleepTime);
//        boolean b = driver.getPageSource().contains(price2a) ||
//                driver.getPageSource().contains(price2b) ||
//                driver.getPageSource().contains(price2c);
//        Assert.assertTrue(b);
//    }
//}