package week11;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;

public class TestAmazonSearchTestNG {
    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeClass
    public void beforeClass() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\harte\\drivers\\chromedriver-win64 (5)\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // Use explicit wait
    }

    @DataProvider(name = "searchItems")
    public Object[][] createData() {
        return new Object[][]{
                {"JBL Speakers", new String[]{"129.95", "299.00", "104.95"}},
                {"cell phones", new String[]{"86.99", "109.99", "119.99"}},
                {"women shoes", new String[]{"33.57", "84.95", "75.00"}}
        };
    }

    @Test(dataProvider = "searchItems")
    public void searchAndCheckPrice(String searchItem, String[] expectedPrices) throws Exception {
        driver.get("https://www.amazon.com/");
        WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("input#twotabsearchtextbox")));

        searchBox.clear();
        searchBox.sendKeys(searchItem + Keys.ENTER);

        // Wait for the parent container of search results
        WebElement searchResultsContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[data-component-type='s-search-result']")));

        List<WebElement> priceElements = searchResultsContainer.findElements(By.cssSelector("span.a-price span.a-offscreen"));

        boolean priceMatchFound = false;

        // Loop through expected prices and actual price elements
        outerloop:
        for (String expectedPrice : expectedPrices) {
            for (WebElement priceElement : priceElements) {
                String textPrice = priceElement.getText().trim().replaceAll("[^0-9.]", ""); // Remove non-numeric characters for comparison
                if (!textPrice.isEmpty() && expectedPrice.equals(textPrice)) { // Use equals for exact match
                    priceMatchFound = true;
                    break outerloop; // Break the outer loop as well
                }
            }
        }

        Assert.assertTrue(priceMatchFound, "Expected price not found for " + searchItem);
        takeScreenshot(searchItem.replace(" ", "_") + "_result");
    }


    @AfterClass
    public void afterClass() {
        driver.quit();
    }

    private void takeScreenshot(String fileName) throws Exception {
        TakesScreenshot ts = (TakesScreenshot) driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(source, new File("./screenshots/" + fileName + "_" + timestamp() + ".png"));
    }

    private String timestamp() {
        return new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
    }
}
