//package week12.Stepdefinition;
//
//import io.cucumber.java.After;
//import io.cucumber.java.Before;
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import java.time.Duration;
//import java.util.Comparator;
//import java.util.List;
//
//public class HolidayShoppingSteps {
//    private WebDriver driver;
//    private WebDriverWait wait;
//
//    @Before
//    public void setup() {
//        System.setProperty("webdriver.chrome.driver", "C:\\Users\\harte\\drivers\\chromedriver-win64\\chromedriver.exe");
//        driver = new ChromeDriver();
//        driver.manage().window().maximize();
//        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//    }
//
//
//    @Given("I am on the Amazon homepage")
//    public void i_am_on_the_amazon_homepage() {
//        driver.get("https://www.amazon.com");
//    }
//
//    @When("I search for {string}")
//    public void i_search_for(String product) {
//        try {
//            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
//            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("twotabsearchtextbox")));
//            searchBox.sendKeys(product);
//            driver.findElement(By.id("nav-search-submit-button")).click();
//        } catch (Exception e) {
//            e.printStackTrace();
//            throw new RuntimeException("Failed to search for product due to an exception", e);
//        }
//    }
//
//
//
//    @And("I select the product with highest rating")
//    public void i_select_the_product_with_highest_rating() {
//        List<WebElement> products = driver.findElements(By.cssSelector("your-product-selector"));
//        WebElement highestRatedProduct = products.stream()
//                .max(Comparator.comparing(p -> extractRating(p)))
//                .orElseThrow(() -> new RuntimeException("No products found"));
//        highestRatedProduct.click();
//    }
//
//
//    private Double extractRating(WebElement product) {
//        String rating = product.findElement(By.cssSelector("your-rating-selector")).getAttribute("textContent");
//        return Double.parseDouble(rating.replace(" out of 5 stars", ""));
//    }
//
//
//    @And("I open the product details")
//    public void i_open_the_product_details() {
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        // Assuming product links are in a list, and you want to click the first one
//        WebElement firstProductLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h2.a-size-mini a")));
//        firstProductLink.click();
//    }
//
//
//    @Then("I add the product to my cart")
//    public void i_add_the_product_to_my_cart() {
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        // Locate and click the 'Add to Cart' button
//        WebElement addToCartButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("add-to-cart-button")));
//        addToCartButton.click();
//
//        // Optional: Handle pop-ups or confirmations if needed
//    }
//
//
//    @After
//    public void tearDown() {
//        if (driver != null) {
//            driver.quit();
//        }
//    }
//}
