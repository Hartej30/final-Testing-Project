//package week12.Stepdefinition;
//
//import org.apache.commons.io.FileUtils;
//import org.apache.log4j.BasicConfigurator;
//import org.apache.log4j.Logger;
//import org.apache.poi.xssf.usermodel.XSSFCell;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.openqa.selenium.By;
//import org.openqa.selenium.OutputType;
//import org.openqa.selenium.TakesScreenshot;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.Assert;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.DataProvider;
//import org.testng.annotations.Test;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.text.SimpleDateFormat;
//import java.time.Duration;
//import java.util.Date;
//import java.util.Objects;
//
//public class TestAmazonSearchBDD {
//    public static WebDriver driver;
//
//    public static String myWebBrowserDriver = "webdriver.chrome.driver";
//    public static String myDriverPath = "C:\\Users\\harte\\drivers\\chromedriver-win64 (5)\\chromedriver-win64\\chromedriver.exe";
//    public static String url = "http://www.amazon.com/";
//    static String screenshotPath = "c://CS522Screenshots";
//    private static XSSFSheet ExcelWSheet;
//    private static XSSFWorkbook ExcelWBook;
//    private static XSSFCell Cell;
//    private String sTestCaseName;
//    private int iTestCaseRow;
//    String xlsxFilePath = "C:\\Users\\harte\\Documents\\SearchItem.xlsx";
//    String xlsxSheet = "Sheet1";
//    String imageExtension = ".png";
//    public static String msg = "not found the price meets my expectation ";
//    private static Logger logger = Logger.getLogger(TestAmazonSearchBDD.class.getName());
//
//
//    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");
//    Date date = new Date();
//
//    @BeforeClass
//    public static void setup() throws InterruptedException {
//        BasicConfigurator.configure();
//        System.setProperty(myWebBrowserDriver, myDriverPath);
//        driver = new ChromeDriver();
//        logger.info("Opening browser!");
//        driver.get(url);
//        driver.manage().window().maximize();
//        Thread.sleep(10000);
//    }
//
//    @AfterClass
//    public static void tearDown(){
//        logger.info("Close browser!");
//        driver.quit();
//    }
//
//    @Test(dataProvider = "ItemPrice")
//    public void searchAllItems(String item, String priceA, String priceB, String priceC) throws Exception {
//        searchItem(item, priceA, priceB, priceC);
//        String fileName = "testitem_" + dateFormat.format(date) + imageExtension;
//        takeSnapShot(driver, screenshotPath + "//" + fileName);
//    }
//
//    public void searchItem(String item1, String priceA, String priceB, String priceC) {
//        driver.findElement(By.name("field-keywords")).clear();
//        driver.findElement(By.name("field-keywords")).sendKeys(item1);
//        if(Objects.equals(item1, "hair straightener")) {
//            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("nav-search-submit-button")));
//            driver.findElement(By.id("nav-search-submit-button")).click();
//        } else {
//            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//            driver.findElement(By.id("nav-search-submit-button")).click();
//        }
//
//        boolean b = driver.getPageSource().contains(priceA) ||
//                driver.getPageSource().contains(priceB) ||
//                driver.getPageSource().contains(priceC);
//
//        try {
//            Assert.assertTrue(b);
//            logger.info("Price match found for the item");
//        } catch(Throwable t) {
//            logger.error("Expected price not found!");
//        }
//    }
//
//    public void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception {
//        TakesScreenshot scrShot =((TakesScreenshot)webdriver);
//
//        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
//        File DestFile=new File(fileWithPath);
//
//        FileUtils.copyFile(SrcFile, DestFile);
//    }
//
//    @DataProvider(name = "ItemPrice")
//    public Object[][] ItemPrice() throws Exception {
//        setExcelFile(xlsxFilePath, xlsxSheet);
//        sTestCaseName = this.toString();
//        sTestCaseName = getTestCaseName(this.toString());
//        iTestCaseRow = getRowContains(sTestCaseName, 0);
//        Object[][] testObjArray = getTableArray(xlsxFilePath, xlsxSheet, iTestCaseRow);
//
//        return (testObjArray);
//    }
//
//    public static void setExcelFile(String Path, String SheetName) throws Exception {
//        try {
//
//            FileInputStream ExcelFile = new FileInputStream(Path);
//            ExcelWBook = new XSSFWorkbook(ExcelFile);
//            ExcelWSheet = ExcelWBook.getSheet(SheetName);
//
//        } catch (Exception e) {
//            logger.error("Error setting Excel file: " + e.getMessage());
//            throw (e);
//        }
//    }
//
//    public static Object[][] getTableArray(String FilePath, String SheetName, int iTestCaseRow) throws Exception {
//        String[][] tabArray = null;
//
//        try {
//            FileInputStream ExcelFile = new FileInputStream(FilePath);
//
//            // Access the required test data sheet
//            ExcelWBook = new XSSFWorkbook(ExcelFile);
//            ExcelWSheet = ExcelWBook.getSheet(SheetName);
//            int startRow = 1;
//            int startCol = 1;
//            int ci, cj;
//            int totalRows = ExcelWSheet.getLastRowNum();
//
//            // you can write a function as well to get Column count
//            int totalCols = 4;
//            tabArray = new String[totalRows][totalCols];
//            ci = 0;
//            for (int i = startRow; i <= totalRows; i++, ci++) {
//                cj = 0;
//                for (int j = startCol; j < totalCols + startCol; j++, cj++) {
//                    tabArray[ci][cj] = getCellData(i, j);
//                    logger.info(tabArray[ci][cj]);
//                }
//            }
//        } catch (FileNotFoundException e) {
//            logger.error("Could not read the Excel sheet: " + e.getMessage());
//            e.printStackTrace();
//        } catch (IOException e) {
//            logger.error("Could not read the Excel sheet: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return (tabArray);
//    }
//
//    public static String getCellData(int RowNum, int ColNum) throws Exception {
//        try {
//            Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
//            String CellData = Cell.getStringCellValue();
//            return CellData;
//        } catch (Exception e) {
//            return "";
//        }
//    }
//
//    public static String getTestCaseName(String sTestCase) throws Exception {
//        String value = sTestCase;
//        try {
//            int posi = value.indexOf("@");
//            value = value.substring(0, posi);
//            posi = value.lastIndexOf(".");
//            value = value.substring(posi + 1);
//            return value;
//        } catch (Exception e) {
//            throw (e);
//        }
//    }
//
//    public static int getRowContains(String sTestCaseName, int colNum) throws Exception {
//        int i;
//        try {
//            int rowCount = getRowUsed();
//            for (i = 0; i < rowCount; i++) {
//                if (getCellData(i, colNum).equalsIgnoreCase(sTestCaseName)) {
//                    break;
//                }
//            }
//            return i;
//        } catch (Exception e) {
//            logger.error("Error occurred while getting the row: " + e.getMessage());
//            throw (e);
//        }
//    }
//
//    public static int getRowUsed() throws Exception {
//        try {
//            int RowCount = ExcelWSheet.getLastRowNum();
//            return RowCount + 1; // Adding 1 because rows are 0-indexed
//        } catch (Exception e) {
//            logger.error("Error occurred while getting the used rows: " + e.getMessage());
//            throw e;
//        }
//    }
//}
