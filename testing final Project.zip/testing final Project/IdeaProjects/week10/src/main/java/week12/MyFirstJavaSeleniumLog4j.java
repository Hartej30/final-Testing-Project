//package week12;
//
//import org.apache.log4j.BasicConfigurator;
//import org.apache.logging.log4j.Level;
//import org.apache.logging.log4j.core.config.Configurator;
//import org.apache.logging.log4j.core.config.DefaultConfiguration;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.interactions.Actions;
//
//public class MyFirstJavaSeleniumLog4j {
//    private static Logger logger = LogManager.getLogger(MyFirstJavaSeleniumLog4j.class);
//
//    public static void main(String[] args) {
//
//        Configurator.initialize(new DefaultConfiguration());
//        Configurator.setRootLevel(Level.INFO);
//
//        String myWebDriverType = "webdriver.gecko.driver";
//        String myWebDriverPath = "C:\\Drivers\\Selenium\\firefox\\geckodriver.exe";
//
//        // 1. What does this line do?
//        System.setProperty(myWebDriverType, myWebDriverPath);
//        logger.info("Set type and path for web driver property.");
//
//        // 2. What does this line do?
//        WebDriver driver = new FirefoxDriver();
//        logger.info("Initiate web driver");
//
//        // 3. Handle Action class
//        Actions actions = new Actions(driver);
//        logger.info("initiate action");
//
//        // 4. What does this line do?
//        driver.get("http://www.google.com");
//        logger.info("Open URL google.com");
//
//        // 5. What does this line do?
//        driver.manage().window().maximize();
//        logger.info("Maximize the window size");
//
//        // 6. What does this line do?
////        driver.findElement(By.name("q")).sendKeys("SFBU");
////        driver.findElement(By.id("APjFqb")).sendKeys("SFBU");
//        driver.findElement(By.id("APjFqb")).sendKeys("SFBU");
//        logger.info("Type SFBU in the google search text field.");
//
//        // 7. Click Enter key
////        actions.sendKeys(Keys.ENTER).build().perform();
//        actions.sendKeys(Keys.ENTER).build().perform();
//        logger.info("Click Enter key");
//
//        // 8. What does this line sfbu.edu
//        driver.navigate().to("http://sfbu.edu");
//        logger.info("Navigate browser to sfbu.edu");
//
//        // 9. Get web page title and print it
//        String actualTitle = driver.getTitle();
////        System.out.println("Current open web page title is " + actualTitle);
//        logger.info("Print current web page title " + actualTitle);
//
//        // 10. What these line do?
////        String expectedTitle = "SFBU | San Francisco Bay University | SFBU";
//        String expectedTitle = "San Francisco Bay University | SFBU";
//        if (actualTitle.contentEquals(expectedTitle)){
////            System.out.println("Test Passed!");
//            logger.info("Page title comparison: " + expectedTitle + " equals to " + actualTitle);
//            logger.info("Test Passed!");
//        } else {
////            System.out.println("Test Failed");
//            logger.warn("Actual page title: " + actualTitle + " is not equals to " + expectedTitle);
//            logger.error("Test Failed!");
//        }
//
//        // 11. Close all and exit
//        driver.quit();
//        logger.info("Close all browser windows and exits all sessions.");
//    }
//}