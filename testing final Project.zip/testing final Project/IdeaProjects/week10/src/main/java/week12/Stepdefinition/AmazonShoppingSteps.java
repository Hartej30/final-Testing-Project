package week12.Stepdefinition;

import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

public class AmazonShoppingSteps {

    private static WebDriver driver;

    @Given("I open the browser and navigate to Amazon")
    public void openBrowserAndNavigateToAmazon() {
        if (driver == null) {
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\harte\\drivers\\chromedriver-win64\\chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
        }
        driver.get("http://www.amazon.com/");
    }

    @When("I navigate directly to the product page")
    public void navigateToProductPage() {
        driver.get("https://www.amazon.com/Apple-iPhone-14-Pro-Max/dp/B0BN94DL3R");
    }

    // Example method to add an item to cart by verifying its price
    public void addItemToCartByPrice(String expectedPrice) {
        // Navigate to the product page as before

        // Find the price element
        List<WebElement> priceElements = driver.findElements(By.cssSelector(".a-price .a-offscreen"));
        boolean priceMatchFound = false;

        for (WebElement priceElement : priceElements) {
            if (priceElement.getText().equals(expectedPrice)) {
                System.out.println("Price Matched: " + expectedPrice);
                priceElement.click(); // Assuming clicking the price navigates correctly
                priceMatchFound = true;
                break;
            }
        }

        if (priceMatchFound) {
            WebElement addToCartButton = new WebDriverWait(driver,Duration.ofSeconds(30))
                    .until(ExpectedConditions.elementToBeClickable(By.id("add-to-cart-button")));
            addToCartButton.click();
            System.out.println("Added to cart");
        } else {
            System.out.println("No matching price found");
        }
    }

    @And("I verify the price and add the product to the cart")
    public void verifyPriceAndAddToCart() {
        // Assuming the expected price is predefined, e.g., "$1099.00"
        String expectedPrice = "$1099.00"; // This could be passed as a parameter or configured elsewhere
        addItemToCartByPrice(expectedPrice);
    }


    @Then("I check that the item has been added to the cart")
    public void verifyItemAddedToCart() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        try {
            // Click the Add to Cart button first
            WebElement addToCartButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='add-to-cart-button']")));
            addToCartButton.click();

            // Now check for the confirmation message
            WebElement confirmationMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(), 'Added to Cart')]")));
            Assert.assertTrue(confirmationMessage.isDisplayed(), "Item not added to cart as expected");
        } catch (Exception e) {
            System.err.println("Failed to verify item in cart: " + e.getMessage());
            captureScreenshot("ItemInCartCheck");
            throw e;
        }
    }


    private void captureScreenshot(String methodName) {
        try {
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File("screenshots/" + methodName + "_" + System.currentTimeMillis() + ".png"));
        } catch (IOException e) {
            System.err.println("Error capturing screenshot: " + e.getMessage());
        }
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            driver = null;
        }
    }
}
