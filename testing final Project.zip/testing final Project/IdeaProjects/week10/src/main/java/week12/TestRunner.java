package week12;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        glue = "week12.Stepdefinition",
        plugin = {
                "pretty", // Makes the console output readable
                "html:target/cucumber-html-report", // HTML report
                "json:target/cucumber.json", // JSON report
                "junit:target/cucumber-results.xml"  // JUnit XML report
        }
)
public class TestRunner {
}
