//package week12.Stepdefinition;
//
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//import org.apache.commons.io.FileUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.junit.AfterClass;
//import org.junit.Assert;
//import org.junit.BeforeClass;
//import org.openqa.selenium.By;
//import org.openqa.selenium.OutputType;
//import org.openqa.selenium.TakesScreenshot;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//import java.io.File;
//import java.text.SimpleDateFormat;
//import java.time.Duration;
//import java.util.Date;
//
//public class AmazonSearchStepDefinitions {
//    private static final Logger logger = LogManager.getLogger(AmazonSearchStepDefinitions.class);
//    public static WebDriver driver;
//
//    public static String myWebBrowserDriver = "webdriver.chrome.driver";
//    public static String myDriverPath = "C:\\Users\\harte\\drivers\\chromedriver-win64 (5)\\chromedriver-win64\\chromedriver.exe";
//    public static String url = "http://www.amazon.com/";
//    static String screenshotPath = "C:\\ CS522 Screenshots";
//    public static String msg = "not found the price meets my expectation ";
//
//    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");
//    Date date = new Date();
//
//    @BeforeClass
//    public static void setup() throws InterruptedException {
//        System.setProperty(myWebBrowserDriver, myDriverPath);
//        driver = new ChromeDriver();
//        logger.info("Opening browser!");
//        driver.get(url);
//        driver.manage().window().maximize();
//        Thread.sleep(20000);
//    }
//
//    @AfterClass
//    public static void tearDown(){
//        logger.info("Close browser!");
//        driver.quit();
//    }
//
//    @Given("I am on the Amazon homepage")
//    public void i_am_on_the_amazon_homepage() {
//        // No need to implement this here as it's already done in the @BeforeClass method
//    }
//
//    @When("I search for {string}")
//    public void i_search_for(String item) {
//        driver.findElement(By.name("field-keywords")).clear();
//        driver.findElement(By.name("field-keywords")).sendKeys(item);
//        driver.findElement(By.id("nav-search-submit-button")).click();
//    }
//
//    @Then("I should see the price of {string} or {string} or {string}")
//    public void i_should_see_the_price_of_or_or(String price1, String price2, String price3) throws Exception {
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//        String fileName = "testitem_" + dateFormat.format(date) + ".png";
//        takeSnapShot(driver, screenshotPath + "//" + fileName);
//
//        boolean b = driver.getPageSource().contains(price1) ||
//                driver.getPageSource().contains(price2) ||
//                driver.getPageSource().contains(price3);
//
//        try {
//            Assert.assertTrue(b);
//            logger.info("Price match found");
//        } catch(Throwable t) {
//            logger.error("Expected price not found!");
//        }
//    }
//
//    public void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception {
//        TakesScreenshot scrShot =((TakesScreenshot)webdriver);
//
//        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
//        File DestFile=new File(fileWithPath);
//
//        FileUtils.copyFile(SrcFile, DestFile);
//    }
//}
