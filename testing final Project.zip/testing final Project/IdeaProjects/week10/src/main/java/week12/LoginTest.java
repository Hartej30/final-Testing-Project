package week12;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

public class LoginTest {
    private WebDriver driver;
    private static final String WEB_DRIVER_ID = "webdriver.chrome.driver";
    private static final String DRIVER_PATH = "C:\\Users\\harte\\drivers\\chromedriver-win64\\chromedriver.exe";
    private static final String URL = "http://www.amazon.com/";
    private static final String SCREENSHOT_PATH = "c://CS522Screenshots";
    private static final String IMAGE_EXTENSION = ".png";
    private static final String USERNAME = "9256648408";
    private static final String PASSWORD = "Hartej@3003";
    private static final Logger LOGGER = Logger.getLogger(LoginTest.class.getName());
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

    @BeforeClass
    public void setup() {
        System.setProperty(WEB_DRIVER_ID, DRIVER_PATH);
        BasicConfigurator.configure();
        driver = new ChromeDriver();
        LOGGER.info("Opening browser");
        driver.get(URL);
        driver.manage().window().maximize();
    }

    @AfterClass
    public void tearDown() {
        LOGGER.info("Close browser!");
        driver.quit();
    }

    @Test(priority = 1)
    public void amazonLogin() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.elementToBeClickable(By.id("nav-link-accountList"))).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ap_email"))).sendKeys(USERNAME);
            driver.findElement(By.id("continue")).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ap_password"))).sendKeys(PASSWORD);
            driver.findElement(By.id("signInSubmit")).click();
        } catch (Exception e) {
            LOGGER.error("Login failed: ", e);
        }
    }

    @Test(priority = 2)
    public void searchAndTakeScreenshot() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("twotabsearchtextbox")));
            searchBox.clear();
            searchBox.sendKeys("Test Item");
            driver.findElement(By.id("nav-search-submit-button")).click();
            WebElement firstResult = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".s-main-slot .s-result-item")));
            firstResult.click();
            takeSnapshot(driver, SCREENSHOT_PATH + "\\" + "testitem_" + dateFormat.format(new Date()) + IMAGE_EXTENSION);
        } catch (Exception e) {
            LOGGER.error("Error during search and screenshot: ", e);
        }
    }

    private void takeSnapshot(WebDriver webdriver, String filePath) {
        try {
            File srcFile = ((TakesScreenshot) webdriver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(srcFile, new File(filePath));
        } catch (Exception e) {
            LOGGER.error("Error taking screenshot: ", e);
        }
    }
}
