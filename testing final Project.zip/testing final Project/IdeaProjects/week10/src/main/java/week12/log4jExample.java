//package week12;
//
//import org.apache.logging.log4j.Level;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.apache.logging.log4j.core.config.Configurator;
//import org.apache.logging.log4j.core.config.DefaultConfiguration;
//
//public class log4jExample {
//    /* Get actual class name to be printed on */
//    private static final Logger logger = LogManager.getLogger(log4jExample.class);
//
//    public static void main(String[] args) {
//        Configurator.initialize(new DefaultConfiguration());
//        Configurator.setRootLevel(Level.INFO);
//
//        logger.info("Hello this is an info message");
//        logger.warn("Hello this is a debug message");
//        logger.error("Hello this is an error message");
//        System.out.println("just print Hi");
//    }
//}